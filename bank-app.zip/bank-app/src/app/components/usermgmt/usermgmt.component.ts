import { UserService } from './../../services/user.service';
import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import * as rootReducers from '../../store/reducers';
import * as UserActions from '../../actions/user.action';
import { NgxSpinnerService } from "ngx-spinner";
import { User } from '../../models/User.model';
import * as actionTypes from '../../actions/types.action';

@Component({
  selector: 'app-usermgmt',
  templateUrl: './usermgmt.component.html',
  styleUrls: ['./usermgmt.component.css']
})
export class UsermgmtComponent implements OnInit {

  current_user: User;
  current_actionType: string;
  loaduser_successMsg: string;
  loaduser_failureMsg: string;
  allUsers: User[] = [];
   // list of action types
   LOAD_USERS_FAILURE: string = actionTypes.LOAD_USERS_FAILURE;

  constructor(private store: Store<rootReducers.AppState>,
    private spinner: NgxSpinnerService,
    private userService: UserService) {    
   }

  ngOnInit() {

    this.store.pipe(select('type')).subscribe(type => {
      this.current_actionType = type;
    })
    
    this.store.pipe(select('type')).subscribe(type => {
      this.current_actionType = type;
    })

    this.store.pipe(select('user')).subscribe(res => {
      //this.current_user = res.current_user;
      //this.store.dispatch(UserActions.LOAD_USERS());
      this.allUsers = res.allUsers;
     
      if (res.loading) {
        this.spinner.show();
      } else {
        this.spinner.hide();
      }

    })
  }

}
