import { Component, OnInit } from '@angular/core';
import * as TransactionActions from '../../actions/transaction.action';
import { Store, select } from '@ngrx/store';
import * as rootReducers from '../../store/reducers';
//import { NgxSpinnerService } from "ngx-spinner";
import * as actionTypes from '../../actions/types.action';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  tranAmountErrMsg: string;

  current_actionType: string;

  transaction_successMsg: string;
  transaction_errorMsg: string;

  // list of action types
  TRANSACTION_FAILURE: string = actionTypes.TRANSACTION_FAILURE;

  constructor(
    private store: Store<rootReducers.AppState>,
  ) { }

  ngOnInit() {
    this.store.pipe(select('type')).subscribe(type => {
      this.current_actionType = type;
    })

    this.store.pipe(select('tran')).subscribe(res => {
      this.tranAmountErrMsg = res.tranAmountErrMsg;
    })

    this.store.pipe(select('tran')).subscribe(res => {
      this.transaction_errorMsg = res.transaction_errorMsg;
      this.transaction_successMsg = res.transaction_successMsg;
      
    })
  }
  
  makeTransaction = (
    tranType: string,
    tranAmount: number
  ) => {
    const body = {
      tranType: tranType,
      tranAmount: tranAmount   
    }
    this.store.dispatch(TransactionActions.TRANSACTION({ payload: body }))
  }

}
