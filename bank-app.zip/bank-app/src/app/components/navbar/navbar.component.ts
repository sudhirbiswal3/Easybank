import { Component, OnInit, Input } from '@angular/core';
import * as rootReducers from '../../store/reducers';
import * as UserActions from '../../actions/user.action';
import { Store, select } from '@ngrx/store';
import { User } from '../../models/User.model';
import { UserService } from './../../services/user.service';
import * as TransactionStore from '../../store/reducers/trans.reducer';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  currentUser: User;
  hasAdminRole: boolean;
  hasCustomerRole: boolean;
  hasEmployeeRole: boolean;
  @Input() active: string;

  constructor(
    private store: Store<rootReducers.AppState>,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.store.pipe(select('user')).subscribe(data => {
      if (data.current_user) {
        this.currentUser = data.current_user;

        if (data.current_user.roles && data.current_user.roles.has('ADMIN')) {
          this.hasAdminRole = true;
        }
      }
    })
  
  }

  onViewUserDetails() {
    this.store.dispatch(UserActions.LOAD_USERS());
  }

  resetSuccessMessage(){
    TransactionStore.initialState.transaction_successMsg = null;
  }

  setActive(tab: string) {
    return {
      'active': this.active === tab,
      'font-weight-bold': this.active === tab
    }
  }

  logout() {
    this.store.dispatch(UserActions.LOG_OUT());
  }

}
