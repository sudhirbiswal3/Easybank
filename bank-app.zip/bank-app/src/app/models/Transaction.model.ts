export interface Transaction {
  tranType: string; //debit,credit
  tranAmount: number;
  transDate: Date
}