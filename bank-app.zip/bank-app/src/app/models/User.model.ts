import { Transaction } from '../models/Transaction.model';
export interface User {
  firstName: string;
  lastName: string;
  roleType: string;
  email: string;
  password: string;
  confirmPassword: string;
  roles: Set<string>;
  transList: Transaction[];
  totalBalance: string;
  
}