import { Transaction } from './../models/Transaction.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class TransService {
  serverAPI_URL = `http://localhost:8085`;

  constructor(
    private http: HttpClient,
    private httpService: HttpService
  ) { }

  transaction = (payload): Observable<any> => {
    const url = `${this.serverAPI_URL}/transaction/add`;
    const httpOptions = this.httpService.getHttpHeader();
    return this.http.post<any>(url, payload, httpOptions);
  }

  getPastTransactions = (payload): Observable<any> => {
    const url = `${this.serverAPI_URL}/transaction/list`;
    const httpOptions = this.httpService.getHttpHeader();
    return this.http.post<any>(url,payload, httpOptions);
  }
}
