import { UsermgmtComponent } from './components/usermgmt/usermgmt.component';
import { Transaction } from './models/Transaction.model';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AlreadyAuthService } from './services/already-auth.service';
import { AuthGuardService } from './services/auth-guard.service';
import {TransactionComponent} from './components/transaction/transaction.component';
 
const routes: Routes = [
  { path: '', component: LoginComponent, canActivate: [AlreadyAuthService] },
  { path: 'login', component: LoginComponent, canActivate: [AlreadyAuthService] },
  { path: 'register', component: RegisterComponent, canActivate: [AlreadyAuthService] },
  { path: 'dashboard/:fullName', component: DashboardComponent, canActivate: [AuthGuardService] },
  { path: 'transaction', component: TransactionComponent, canActivate: [AuthGuardService] },
  { path: 'usermgmt', component: UsermgmtComponent, canActivate: [AuthGuardService] },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuardService, AlreadyAuthService]
})
export class AppRoutingModule { }
