import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import * as TransactionActions from '../../actions/transaction.action';
import * as TypeActions from '../../actions/defineType.action';
import * as actionTypes from '../../actions/types.action';
import { mergeMap, map, catchError, switchMap, tap } from 'rxjs/operators';
import { TransService } from '../../services/trans.service';
import { of } from 'rxjs';
import { Router } from '@angular/router';

@Injectable()
export class TransEffects {

  constructor(
    private actions$: Actions,
    private transService: TransService,
    private router: Router
  ) { }

  
  transaction = createEffect(() =>
    this.actions$.pipe(
      ofType(TransactionActions.TRANSACTION),
      switchMap((data) => {
        return this.transService.transaction(data.payload).pipe(       
          switchMap(res => {              
            return [
              TransactionActions.TRANSACTION_SUCCESS({ payload: 'Transaction Successful' }),
              TypeActions.SET_TYPE({ actionType: actionTypes.TRANSACTION_SUCCESS })
            ]
          }),
          catchError(errs => {
            return of(
              TransactionActions.TRANSACTION_FAILURE({
                payload: {
                  data: { ...errs.error },
                  error_msg: errs.error.generalErr
                }
              }),
              TypeActions.SET_TYPE({ actionType: actionTypes.TRANSACTION_FAILURE })
            );
          })
        )
      })
    )
  )

  getPastTransactions = createEffect(() =>
    this.actions$.pipe(
      ofType(TransactionActions.TRANSACTION_ALL),
      mergeMap((data) => {
        return this.transService.getPastTransactions(data.payload).pipe(
          switchMap(res => {
           
            return [          
              TransactionActions.TRANSACTION_ALL({
                payload: {
                  data: { ...res },                
                }
              }),              
            ]
          }),
        )
      })
    )
  )
  
}
