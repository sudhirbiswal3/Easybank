import { createReducer, on } from '@ngrx/store';
import { Transaction } from '../../models/Transaction.model';
import * as TransactionActions from '../../actions/transaction.action';
import * as actionTypes from '../../actions/types.action';
export interface TransactionState {
   
    allTransByLimit: Transaction[];
    // Register User Message
    transaction_successMsg: string;
    transaction_errorMsg: string;
    tranAmountErrMsg: string;
    current_actionType: string;
    past_tran: string
  }

  
  export const initialState = {
   
    allTransByLimit: [],
    // Register User Message
    transaction_successMsg: null,
    transaction_errorMsg: null,

    tranAmountErrMsg: null,
    current_actionType: null
  
  }
  
  const _tranReducer = createReducer(initialState,
   
    on(TransactionActions.TRANSACTION, (state, action) => {
      return {
        ...state,
        loading: true,
        transaction_successMsg: null,
        transaction_errorMsg: null
      }
    }),
    on(TransactionActions.TRANSACTION_SUCCESS, (state, action) => {
      return {
        ...action.payload,
        loading: false,
        transaction_successMsg: action.payload,
        transaction_errorMsg: null,
      }
    }),
    on(TransactionActions.TRANSACTION_FAILURE, (state, action) => {    
      return {
        ...action.payload.data,
        loading: false,
        transaction_successMsg: null,
        transaction_errorMsg: action.payload.error_msg
      }
    }),
    on(TransactionActions.TRANSACTION_ALL, (state, action) => {
        return {
          ...state,
          loading: false,
          allTransByLimit: action.payload
        }
      }),
      
  );
  
  export function tranReducer(state, action) {
    return _tranReducer(state, action);
  }