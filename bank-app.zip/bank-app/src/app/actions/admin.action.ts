import { createAction, props } from '@ngrx/store';
import * as actionTypes from './types.action';

export const ADMIN_DELETE_USER = createAction(
  actionTypes.ADMIN_DELETE_USER,
  props<{ payload: any }>()
)

export const ADMIN_ADD_USER = createAction(
  actionTypes.ADMIN_ADD_USER,
  props<{ payload: any }>()
)

export const ADMIN_ADD_USER_SUCCESS = createAction(
  actionTypes.ADMIN_ADD_USER_SUCCESS,
  props<{ payload: any }>()
)

export const ADMIN_ADD_USER_FAILED = createAction(
  actionTypes.ADMIN_ADD_USER_FAILED,
  props<{ payload: any }>()
)
