import { createAction, props } from '@ngrx/store';
import * as actionTypes from './types.action';

/** ============================
 * Authentication for user
 * ============================
 */
export const TRANSACTION = createAction(
  actionTypes.TRANSACTION,
  props<{ payload: any }>()
)

export const TRANSACTION_ALL = createAction(
  actionTypes.TRANSACTION_ALL,
  props<{ payload: any }>()
)

export const TRANSACTION_SUCCESS = createAction(
  actionTypes.TRANSACTION_SUCCESS,
  props<{ payload: any }>()
)

export const TRANSACTION_FAILURE = createAction(
  actionTypes.TRANSACTION_FAILURE,
  props<{ payload: any }>()
)