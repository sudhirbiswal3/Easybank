// USER related types
export const LOG_IN = '[USER] User Login';
export const LOG_IN_SUCCESS = '[USER] User Login Success';
export const LOG_IN_FAILURE = '[USER] User Login Failure';
export const GET_CURRENT_USER = '[USER] Get current user';
export const SET_CURRENT_USER = '[USER] Set current user';
export const REGISTER = '[USER] User register';
export const REGISTER_SUCCESS = '[USER] User register success';
export const REGISTER_FAILURE = '[USER] User register failure';
export const LOG_OUT = '[USER] User Logout';
export const LOG_OUT_SUCCESS = '[USER] User Logout Success';
export const SET_CURRENT_TRAN = '[USER] Set current tran';

// Load users
export const LOAD_USERS = '[USER] Load Users';
export const LOAD_USERS_SUCCESS = '[USER] Load Users Success';
export const LOAD_USERS_FAILURE = '[USER] Load Users Failure';

// CRUD USER
export const EDIT_USER = '[USER] Edit User';
export const EDIT_USER_SUCCESS = '[USER] Edit User Success';
export const EDIT_USER_FAILURE = '[USER] Edit User Failure';
export const DELETE_USER = '[USER] Delete User';
export const DELETE_USER_SUCCESS = '[USER] Delete User Success';
export const DELETE_USER_FAILURE = '[USER] Delete User Failure';

// ADMIN actions
export const ADMIN_DELETE_USER = '[ADMIN] Delete User';
export const ADMIN_ADD_USER = '[ADMIN] Add user';
export const ADMIN_ADD_USER_SUCCESS = '[ADMIN] Add user success';
export const ADMIN_ADD_USER_FAILED = '[ADMIN] Add user failed';


// Transactions
export const TRANSACTION_ALL = '[TRANSACTION] Load all transactions';
export const TRANSACTION = '[TRANSACTION] Tranaction Start';
export const TRANSACTION_SUCCESS = '[TRANSACTION] Tranaction Success';
export const TRANSACTION_FAILURE = '[TRANSACTION] Tranaction Failure';
export const TRANSACTION_TOTAL = '[TRANSACTION] Tranaction Total';
export const TRANSACTION_TOTAL_SUCCESS = '[TRANSACTION] Tranaction Total Success';
export const TRANSACTION_TOTAL_FAILURE = '[TRANSACTION] Tranaction Total Failure';

// Action Type
export const SET_TYPE = '[TYPE] Set type';
export const CLEAR_TYPE = '[TYPE] Clear type';

