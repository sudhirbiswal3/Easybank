import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { NgxSpinnerModule } from "ngx-spinner"
import { UserEffects } from './store/effects/user.effect';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { rootReducers, reducers , metaReducers } from './store/reducers';
import { TransactionComponent } from './components/transaction/transaction.component';
import { TransEffects } from './store/effects/trans.effect';
import { UsermgmtComponent } from './components/usermgmt/usermgmt.component';

@NgModule({
  declarations: [
    AppComponent,  
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    NavbarComponent,
    FooterComponent,
    TransactionComponent,
    UsermgmtComponent    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    NgxSpinnerModule,
    StoreModule.forRoot(reducers),
    StoreModule.forRoot(reducers, {
			metaReducers,
			runtimeChecks: {
				strictStateImmutability: true,
				strictActionImmutability: true
			}
		}),
    EffectsModule.forRoot([UserEffects,TransEffects])   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
