var navMain = document.getElementById('navbarsExampleDefault')
if (navMain != null) {
  navMain.onclick = function () {
    navMain.classList.remove("show");
  }
}

